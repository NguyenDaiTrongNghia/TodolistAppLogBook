package com.example.yoga;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ClassDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_class_details);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        long instanceId = getIntent().getLongExtra("instance_id", -1);
        if (instanceId != -1) {
            Cursor cursor = MainActivity.helper.searchClasses("", ""); // Get all fields
            if (cursor.moveToFirst()) {
                do {
                    int idIndex = cursor.getColumnIndex("_id");
                    if (idIndex >= 0 && cursor.getLong(idIndex) == instanceId) {
                        displayClassDetails(cursor);
                        break;
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
        } else {
            Toast.makeText(this, "Invalid class instance ID", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void displayClassDetails(Cursor cursor) {
        TextView tvDate = findViewById(R.id.tvDetailDate);
        TextView tvTeacher = findViewById(R.id.tvDetailTeacher);
        TextView tvDay = findViewById(R.id.tvDetailDay);
        TextView tvTime = findViewById(R.id.tvDetailTime);
        TextView tvType = findViewById(R.id.tvDetailType);
        TextView tvDesc = findViewById(R.id.tvDetailDescription);
        TextView tvPrice = findViewById(R.id.tvDetailPrice);
        TextView tvCapacity = findViewById(R.id.tvDetailCapacity);
        TextView tvDuration = findViewById(R.id.tvDetailDuration);

        // Helper method to safely get string or default value
        setTextIfColumnExists(tvDate, cursor, "date", "N/A");
        setTextIfColumnExists(tvTeacher, cursor, "teacher", "N/A");
        setTextIfColumnExists(tvDay, cursor, "dayofweek", "N/A");
        setTextIfColumnExists(tvTime, cursor, "time", "N/A");
        setTextIfColumnExists(tvType, cursor, "type", "N/A");
        setTextIfColumnExists(tvDesc, cursor, "description", "N/A");

        // Handle numeric values
        int priceIndex = cursor.getColumnIndex("price");
        tvPrice.setText(priceIndex >= 0 ? String.valueOf(cursor.getFloat(priceIndex)) : "N/A");

        int capacityIndex = cursor.getColumnIndex("capacity");
        tvCapacity.setText(capacityIndex >= 0 ? String.valueOf(cursor.getFloat(capacityIndex)) : "N/A");

        int durationIndex = cursor.getColumnIndex("duration");
        tvDuration.setText(durationIndex >= 0 ? String.valueOf(cursor.getFloat(durationIndex)) : "N/A");
    }

    private void setTextIfColumnExists(TextView textView, Cursor cursor, String columnName, String defaultValue) {
        int columnIndex = cursor.getColumnIndex(columnName);
        textView.setText(columnIndex >= 0 ? cursor.getString(columnIndex) : defaultValue);
    }
}