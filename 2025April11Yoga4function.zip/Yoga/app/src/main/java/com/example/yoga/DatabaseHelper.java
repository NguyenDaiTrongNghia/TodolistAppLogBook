package com.example.yoga;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
public class DatabaseHelper extends SQLiteOpenHelper {
    private SQLiteDatabase database;

    public DatabaseHelper(Context context){
        super(context, "YogaDB", null, 1);
        database = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            String CREATE_TABLE_YOGACOURSE = "CREATE TABLE YogaCourse(_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "dayofweek TEXT, time TEXT, capacity FLOAT, duration FLOAT, price FLOAT, type TEXT, description TEXT)";
            db.execSQL(CREATE_TABLE_YOGACOURSE);

            // Add this to your DatabaseHelper.java inside onCreate()
            String CREATE_TABLE_CLASS_INSTANCES = "CREATE TABLE ClassInstances(_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "course_id INTEGER, date TEXT, teacher TEXT, comments TEXT," +
                    "FOREIGN KEY(course_id) REFERENCES YogaCourse(_id))";
            db.execSQL(CREATE_TABLE_CLASS_INSTANCES);

        } catch (Exception e) {
            Log.e("Database Error", "Error creating table", e);
        }
    }

    @Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + "YogaCourse");
        Log.w(this.getClass().getName(), "YogaCourse" + " upgrade to version "
                + newVersion + " old data lost");
        onCreate(db);
    }

    // Add these methods to DatabaseHelper.java
    public long addClassInstance(long courseId, String date, String teacher, String comments) {
        ContentValues values = new ContentValues();
        values.put("course_id", courseId);
        values.put("date", date);
        values.put("teacher", teacher);
        values.put("comments", comments);
        return database.insertOrThrow("ClassInstances", null, values);
    }

    public Cursor getClassInstancesForCourse(long courseId) {
        return database.query("ClassInstances",
                new String[]{"_id", "date", "teacher", "comments", "course_id"}, // Include all needed columns
                "course_id = ?",
                new String[]{String.valueOf(courseId)},
                null, null, "date ASC");
    }
    public int updateClassInstance(long instanceId, String date, String teacher, String comments) {
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("teacher", teacher);
        values.put("comments", comments);
        return database.update("ClassInstances", values, "_id = ?",
                new String[]{String.valueOf(instanceId)});
    }
    public int deleteClassInstance(long instanceId) {
        return database.delete("ClassInstances", "_id = ?", new String[]{String.valueOf(instanceId)});
    }

    public long createNewYogaCourse (String dow, String time, float cap, float d, float p, String type, String des) {
        ContentValues rowValues = new ContentValues();
        rowValues.put("dayofweek", dow);
        rowValues.put("time", time);
        rowValues.put("capacity", cap);
        rowValues.put("duration", d);
        rowValues.put("price",p);
        rowValues.put("type", type);
        rowValues.put("description", des);
        return database.insertOrThrow("YogaCourse",  null, rowValues);
    }

    public Cursor readAllYogaCourse(){
        Cursor results = database.query("YogaCourse",
                new String[] {"_id", "dayofweek", "time", "capacity", "duration", "price", "type", "description"},
                null, null, null, null, null);
        results.moveToFirst();
        return  results;
    }
    public int deleteYogaCourse(long id) {
        return database.delete("YogaCourse", "_id = ?", new String[]{String.valueOf(id)});
    }

    public int updateYogaCourse(long id, String dow, String time, float cap, float d, float p, String type, String des) {
        ContentValues rowValues = new ContentValues();
        rowValues.put("dayofweek", dow);
        rowValues.put("time", time);
        rowValues.put("capacity", cap);
        rowValues.put("duration", d);
        rowValues.put("price", p);
        rowValues.put("type", type);
        rowValues.put("description", des);
        return database.update("YogaCourse", rowValues, "_id = ?", new String[]{String.valueOf(id)});
    }
    public Cursor getCourseById(long id) {
        return database.query("YogaCourse",
                new String[]{"_id", "dayofweek", "time", "capacity", "duration", "price", "type", "description"},
                "_id = ?",
                new String[]{String.valueOf(id)},
                null, null, null);
    }

    public Cursor searchClasses(String teacherName, String dayOfWeek) {
        // Modified query to select distinct courses, even when joining with ClassInstances
        String query = "SELECT DISTINCT yc._id, yc.dayofweek, yc.time, yc.capacity, yc.duration, yc.price, yc.type, yc.description " +
                "FROM YogaCourse yc " +
                "LEFT JOIN ClassInstances ci ON ci.course_id = yc._id " +
                "WHERE (ci.teacher LIKE ? OR ci.teacher IS NULL) " +
                (dayOfWeek.isEmpty() ? "" : "AND yc.dayofweek = ?") +
                " ORDER BY yc._id ASC";

        String[] selectionArgs = dayOfWeek.isEmpty() ?
                new String[]{"%" + teacherName + "%"} :
                new String[]{"%" + teacherName + "%", dayOfWeek};

        return database.rawQuery(query, selectionArgs);
    }
}
