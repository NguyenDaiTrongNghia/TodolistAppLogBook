package com.example.yoga;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;
import java.util.Locale;

public class EditInstanceActivity extends AppCompatActivity {
    private long instanceId;
    private EditText edDate, edTeacher, edComments;
    private String selectedDayOfWeek;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_instance);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        dbHelper = new DatabaseHelper(this);

        // Get instance details from intent
        instanceId = getIntent().getLongExtra("instance_id", -1);
        selectedDayOfWeek = getIntent().getStringExtra("course_day");

        edDate = findViewById(R.id.edDate);
        edTeacher = findViewById(R.id.edTeacher);
        edComments = findViewById(R.id.edComments);

        // Set existing values
        edDate.setText(getIntent().getStringExtra("date"));
        edTeacher.setText(getIntent().getStringExtra("teacher"));
        edComments.setText(getIntent().getStringExtra("comments"));

        // Set up date picker
        edDate.setFocusable(false);
        edDate.setClickable(true);
        edDate.setOnClickListener(v -> showDatePicker());

        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> saveChanges());

        Button btnCancel = findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(v -> finish());
    }

    private void showDatePicker() {
        // Parse existing date if available
        String currentDate = edDate.getText().toString();
        Calendar calendar = Calendar.getInstance();

        try {
            String[] dateParts = currentDate.split("/");
            calendar.set(
                    Integer.parseInt(dateParts[2]),
                    Integer.parseInt(dateParts[1]) - 1,
                    Integer.parseInt(dateParts[0])
            );
        } catch (Exception e) {
            // Use current date if parsing fails
            calendar = Calendar.getInstance();
        }

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, day) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(year, month, day);

                    String selectedDateDayOfWeek = getDayOfWeek(selectedDate.get(Calendar.DAY_OF_WEEK));

                    if (!selectedDateDayOfWeek.equals(selectedDayOfWeek)) {
                        Toast.makeText(this,
                                String.format("This course runs on %s. Please select a %s",
                                        selectedDayOfWeek, selectedDayOfWeek),
                                Toast.LENGTH_LONG).show();
                        return;
                    }

                    String formattedDate = String.format(Locale.getDefault(),
                            "%02d/%02d/%04d", day, month + 1, year);
                    edDate.setText(formattedDate);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private void saveChanges() {
        String date = edDate.getText().toString().trim();
        String teacher = edTeacher.getText().toString().trim();
        String comments = edComments.getText().toString().trim();

        if (date.isEmpty() || teacher.isEmpty()) {
            Toast.makeText(this, "Date and Teacher are required", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate date format and day of week
        try {
            String[] dateParts = date.split("/");
            int day = Integer.parseInt(dateParts[0]);
            int month = Integer.parseInt(dateParts[1]) - 1;
            int year = Integer.parseInt(dateParts[2]);

            Calendar selectedDate = Calendar.getInstance();
            selectedDate.set(year, month, day);

            String selectedDateDayOfWeek = getDayOfWeek(selectedDate.get(Calendar.DAY_OF_WEEK));

            if (!selectedDateDayOfWeek.equals(selectedDayOfWeek)) {
                Toast.makeText(this,
                        String.format("This course runs on %s. Please select a %s",
                                selectedDayOfWeek, selectedDayOfWeek),
                        Toast.LENGTH_LONG).show();
                return;
            }
        } catch (Exception e) {
            Toast.makeText(this, "Invalid date format. Please use dd/MM/yyyy", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update the instance
        dbHelper.updateClassInstance(instanceId, date, teacher, comments);
        Toast.makeText(this, "Changes saved", Toast.LENGTH_SHORT).show();

        setResult(RESULT_OK); // Set result to indicate success
        finish();
    }

    private String getDayOfWeek(int calendarDayOfWeek) {
        switch (calendarDayOfWeek) {
            case Calendar.SUNDAY: return "Sun";
            case Calendar.MONDAY: return "Mon";
            case Calendar.TUESDAY: return "Tue";
            case Calendar.WEDNESDAY: return "Wed";
            case Calendar.THURSDAY: return "Thu";
            case Calendar.FRIDAY: return "Fri";
            case Calendar.SATURDAY: return "Sat";
            default: return "";
        }
    }

    @Override
    protected void onDestroy() {
        if (dbHelper != null) {
            dbHelper.close();
        }
        super.onDestroy();
    }
}