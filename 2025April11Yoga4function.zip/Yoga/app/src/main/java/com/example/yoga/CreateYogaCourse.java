package com.example.yoga;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateYogaCourse extends AppCompatActivity {
    long courseId = -1;
    Spinner spDay, spTime, spType;
    EditText edCap, edDur, edPrice, edDes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_yoga_course);

        // Find views
        spDay = findViewById(R.id.spDayOfWeek);
        spTime = findViewById(R.id.spTime);
        spType = findViewById(R.id.spType);
        edCap = findViewById(R.id.edCapacity);
        edDur = findViewById(R.id.edDuration);
        edPrice = findViewById(R.id.edPrice);
        edDes = findViewById(R.id.eTMDes);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Handle edit mode
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("id")) {
            courseId = extras.getLong("id");

            // Set values from extras
            spDay.setSelection(getSpinnerIndex(spDay, extras.getString("dayofweek")));
            spTime.setSelection(getSpinnerIndex(spTime, extras.getString("time")));
            spType.setSelection(getSpinnerIndex(spType, extras.getString("type")));
            edCap.setText(String.valueOf(extras.getFloat("capacity")));
            edDur.setText(String.valueOf(extras.getFloat("duration")));
            edPrice.setText(String.valueOf(extras.getFloat("price")));
            edDes.setText(extras.getString("description"));
        }
    }
    public void onClickCreateYogaCourse(View v) {
        String dayOfWeek = spDay.getSelectedItem().toString();
        String time = spTime.getSelectedItem().toString();
        String type = spType.getSelectedItem().toString();
        String capacityStr = edCap.getText().toString().trim();
        String durationStr = edDur.getText().toString().trim();
        String priceStr = edPrice.getText().toString().trim();
        String description = edDes.getText().toString().trim(); // Optional

        // Validate required fields
        if (dayOfWeek.isEmpty() || time.isEmpty() || type.isEmpty() ||
                capacityStr.isEmpty() || durationStr.isEmpty() || priceStr.isEmpty()) {
            Toast.makeText(this, "Please fill in all required fields.", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            float capacity = Float.parseFloat(capacityStr);
            float duration = Float.parseFloat(durationStr);
            float price = Float.parseFloat(priceStr);

            if (courseId == -1) {
                MainActivity.helper.createNewYogaCourse(dayOfWeek, time, capacity, duration, price, type, description);
                Toast.makeText(this, "A yoga class is just created", Toast.LENGTH_LONG).show();
            } else {
                MainActivity.helper.updateYogaCourse(courseId, dayOfWeek, time, capacity, duration, price, type, description);
                Toast.makeText(this, "Yoga class updated", Toast.LENGTH_LONG).show();
            }

            finish(); // Go back to main screen

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers for Capacity, Duration, and Price.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    // Helper method to get spinner index by value
    private int getSpinnerIndex(Spinner spinner, String value) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                return i;
            }
        }
        return 0; // Default to first item if not found
    }
}