package com.example.yoga;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;
import java.util.Locale;

public class ClassInstancesActivity extends AppCompatActivity {
    private long courseId;
    private EditText edDate, edTeacher, edComments;
    public DatabaseHelper dbHelper;
    public String selectedDayOfWeek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_class_instances);

        dbHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        courseId = getIntent().getLongExtra("course_id", -1);
        if (courseId == -1) {
            Toast.makeText(this, "Invalid course selected", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Get course details and set up UI
        setupCourseDetails();

        edDate = findViewById(R.id.edDate);
        edTeacher = findViewById(R.id.edTeacher);
        edComments = findViewById(R.id.edComments);

        // Set up date picker
        edDate.setFocusable(false);
        edDate.setClickable(true);
        edDate.setOnClickListener(v -> showDatePicker());

        Button btnAddInstance = findViewById(R.id.btnAddInstance);
        btnAddInstance.setOnClickListener(v -> addClassInstance());

        refreshClassInstancesList();
    }

    private void setupCourseDetails() {
        Cursor courseCursor = dbHelper.getCourseById(courseId);
        if (courseCursor != null && courseCursor.moveToFirst()) {
            int dayOfWeekIndex = courseCursor.getColumnIndex("dayofweek");
            int timeIndex = courseCursor.getColumnIndex("time");

            if (dayOfWeekIndex >= 0) {
                selectedDayOfWeek = courseCursor.getString(dayOfWeekIndex);
            }

            if (timeIndex >= 0) {
                String time = courseCursor.getString(timeIndex);
                TextView tvCourseInfo = findViewById(R.id.tvCourseInfo);
                tvCourseInfo.setText(String.format("%s at %s", selectedDayOfWeek, time));
            }
            courseCursor.close();
        }
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);

                    String selectedDateDayOfWeek = getDayOfWeek(selectedDate.get(Calendar.DAY_OF_WEEK));

                    if (!selectedDateDayOfWeek.equals(selectedDayOfWeek)) {
                        Toast.makeText(this,
                                String.format("This course runs on %s. Please select a %s",
                                        selectedDayOfWeek, selectedDayOfWeek),
                                Toast.LENGTH_LONG).show();
                        return;
                    }

                    String formattedDate = String.format(Locale.getDefault(),
                            "%02d/%02d/%04d", selectedDay, selectedMonth + 1, selectedYear);
                    edDate.setText(formattedDate);
                },
                year, month, day);

        // Optional: Restrict to future dates
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private String getDayOfWeek(int calendarDayOfWeek) {
        switch (calendarDayOfWeek) {
            case Calendar.SUNDAY: return "Sun";
            case Calendar.MONDAY: return "Mon";
            case Calendar.TUESDAY: return "Tue";
            case Calendar.WEDNESDAY: return "Wed";
            case Calendar.THURSDAY: return "Thu";
            case Calendar.FRIDAY: return "Fri";
            case Calendar.SATURDAY: return "Sat";
            default: return "";
        }
    }

    private void addClassInstance() {
        String date = edDate.getText().toString().trim();
        String teacher = edTeacher.getText().toString().trim();
        String comments = edComments.getText().toString().trim();

        if (date.isEmpty() || teacher.isEmpty()) {
            Toast.makeText(this, "Date and Teacher are required", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate date format and day of week
        try {
            String[] dateParts = date.split("/");
            int day = Integer.parseInt(dateParts[0]);
            int month = Integer.parseInt(dateParts[1]) - 1;
            int year = Integer.parseInt(dateParts[2]);

            Calendar selectedDate = Calendar.getInstance();
            selectedDate.set(year, month, day);

            String selectedDateDayOfWeek = getDayOfWeek(selectedDate.get(Calendar.DAY_OF_WEEK));

            if (!selectedDateDayOfWeek.equals(selectedDayOfWeek)) {
                Toast.makeText(this,
                        String.format("This course runs on %s. Please select a %s",
                                selectedDayOfWeek, selectedDayOfWeek),
                        Toast.LENGTH_LONG).show();
                return;
            }
        } catch (Exception e) {
            Toast.makeText(this, "Invalid date format. Please use dd/MM/yyyy", Toast.LENGTH_SHORT).show();
            return;
        }

        dbHelper.addClassInstance(courseId, date, teacher, comments);
        Toast.makeText(this, "Class instance added", Toast.LENGTH_SHORT).show();

        // Clear fields and refresh list
        edDate.setText("");
        edTeacher.setText("");
        edComments.setText("");
        refreshClassInstancesList();
    }

    private void refreshClassInstancesList() {
        Cursor instancesCursor = dbHelper.getClassInstancesForCourse(courseId);
        ClassInstanceCursorAdapter adapter = new ClassInstanceCursorAdapter(
                this, R.layout.class_instance_item, instancesCursor, 0);
        ListView lv = findViewById(R.id.lvClassInstances);
        lv.setAdapter(adapter);
    }

    public long getCourseId() {
        return courseId;
    }

    @Override
    protected void onDestroy() {
        if (dbHelper != null) {
            dbHelper.close();
        }
        super.onDestroy();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            refreshClassInstancesList(); // Refresh the list when returning from edit
        }
    }
}

class ClassInstanceCursorAdapter extends CursorAdapter {
    public ClassInstanceCursorAdapter(Context context, int layout, Cursor cursor, int flags) {
        super(context, cursor, flags);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.class_instance_item, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView tvDate = view.findViewById(R.id.tvDate);
        TextView tvTeacher = view.findViewById(R.id.tvTeacher);
        TextView tvComments = view.findViewById(R.id.tvComments);
        View layoutComments = view.findViewById(R.id.layoutComments);

        // Get column indices
        int dateIndex = cursor.getColumnIndex("date");
        int teacherIndex = cursor.getColumnIndex("teacher");
        int commentsIndex = cursor.getColumnIndex("comments");
        int idIndex = cursor.getColumnIndex("_id");

        if (dateIndex >= 0 && teacherIndex >= 0 && idIndex >= 0) {
            String dateStr = cursor.getString(dateIndex);
            String teacherStr = cursor.getString(teacherIndex);

            tvDate.setText(dateStr);
            tvTeacher.setText(teacherStr);

            if (commentsIndex >= 0) {
                String comments = cursor.getString(commentsIndex);
                if (comments != null && !comments.isEmpty()) {
                    tvComments.setText(comments);
                    layoutComments.setVisibility(View.VISIBLE);
                } else {
                    layoutComments.setVisibility(View.GONE);
                }
            }

            final long instanceId = cursor.getLong(idIndex);

            // Delete button
            view.findViewById(R.id.btnDeleteInstance).setOnClickListener(v -> {
                ((ClassInstancesActivity) context).dbHelper.deleteClassInstance(instanceId);
                Toast.makeText(context, "Instance deleted", Toast.LENGTH_SHORT).show();
                changeCursor(((ClassInstancesActivity) context).dbHelper.getClassInstancesForCourse(
                        ((ClassInstancesActivity) context).getCourseId()));
            });

            // Edit button
            Button btnEdit = view.findViewById(R.id.btnEditInstance);
            btnEdit.setOnClickListener(v -> {
                Intent intent = new Intent(context, EditInstanceActivity.class);
                intent.putExtra("instance_id", instanceId);
                intent.putExtra("date", dateStr);
                intent.putExtra("teacher", teacherStr);
                intent.putExtra("comments", commentsIndex >= 0 ? cursor.getString(commentsIndex) : "");
                intent.putExtra("course_day", ((ClassInstancesActivity) context).selectedDayOfWeek);
                ((ClassInstancesActivity) context).startActivityForResult(intent, 1);
            });
        }
    }
}