package com.example.yoga;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ResourceCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    public static DatabaseHelper helper;
    private EditText etSearchTeacher;
    private Spinner spSearchDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        helper = new DatabaseHelper(getApplicationContext());

        etSearchTeacher = findViewById(R.id.etSearchTeacher);
        spSearchDay = findViewById(R.id.spSearchDay);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Add text watcher for teacher name search
        etSearchTeacher.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                updateListView();
            }
        });

        // Add listener for day spinner
        spSearchDay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateListView();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }


    public void onCreateYogaCourse(View v) {
        Intent i = new Intent(getApplicationContext(), CreateYogaCourse.class);
        startActivity(i);
    }

    @Override
    protected void onStart() {
        super.onStart();
        updateListView();
    }
    private void updateListView() {
        String teacherQuery = etSearchTeacher.getText().toString().trim();
        String dayQuery = spSearchDay.getSelectedItem().toString();
        if (dayQuery.equals("All")) dayQuery = "";

        Cursor cursor = helper.searchClasses(teacherQuery, dayQuery);
        YogaCourseCursorAdapter adapter = new YogaCourseCursorAdapter(this, R.layout.yoga_course_item, cursor, 0);
        ListView lv = findViewById(R.id.lvCourse);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener((parent, view, position, id) -> {
            Cursor selectedCursor = (Cursor) adapter.getItem(position);
            int idIndex = selectedCursor.getColumnIndex("_id");
            if (idIndex >= 0) {  // Check if column exists
                Intent intent = new Intent(MainActivity.this, ClassDetailsActivity.class);
                intent.putExtra("course_id", selectedCursor.getLong(idIndex));
                //intent.putExtra("instance_id", selectedCursor.getLong(idIndex));
                startActivity(intent);
            } else {
                Toast.makeText(this, "Error: Unable to find class ID", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
class YogaCourseCursorAdapter extends ResourceCursorAdapter {
    public YogaCourseCursorAdapter(Context context, int layout, Cursor cursor, int flags) {
        super(context, layout, cursor, flags);
    }

    @SuppressLint("Range")
    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView dow = view.findViewById(R.id.tvDayOfWeek);
        TextView type = view.findViewById(R.id.tvType);
        TextView time = view.findViewById(R.id.tvTime);
        TextView des = view.findViewById(R.id.tvDescription);
        TextView price = view.findViewById(R.id.tvPrice);
        TextView capacity = view.findViewById(R.id.tvCapacity);
        TextView duration = view.findViewById(R.id.tvDuration);

        // Safely get column indices and set text
        int dowIndex = cursor.getColumnIndex("dayofweek");
        dow.setText(dowIndex >= 0 ? cursor.getString(dowIndex) : "N/A");

        int typeIndex = cursor.getColumnIndex("type");
        type.setText(typeIndex >= 0 ? cursor.getString(typeIndex) : "N/A");

        int timeIndex = cursor.getColumnIndex("time");
        time.setText(timeIndex >= 0 ? cursor.getString(timeIndex) : "N/A");

        int desIndex = cursor.getColumnIndex("description");
        des.setText(desIndex >= 0 ? cursor.getString(desIndex) : "N/A");

        int priceIndex = cursor.getColumnIndex("price");
        price.setText(priceIndex >= 0 ? String.valueOf(cursor.getFloat(priceIndex)) : "N/A");

        int capacityIndex = cursor.getColumnIndex("capacity");
        capacity.setText(capacityIndex >= 0 ? String.valueOf(cursor.getFloat(capacityIndex)) : "N/A");

        int durationIndex = cursor.getColumnIndex("duration");
        duration.setText(durationIndex >= 0 ? String.valueOf(cursor.getFloat(durationIndex)) : "N/A");

        long id = cursor.getLong(cursor.getColumnIndex("_id"));

        Button btnDelete = view.findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(v -> {
            ((MainActivity) context).helper.deleteYogaCourse(id);
            Toast.makeText(context, "Course deleted", Toast.LENGTH_SHORT).show();
            ((MainActivity) context).onStart(); // Refresh list
        });

        Button btnEdit = view.findViewById(R.id.btnEdit);
        btnEdit.setOnClickListener(v -> {
            Intent i = new Intent(context, CreateYogaCourse.class);
            i.putExtra("id", id);
            i.putExtra("dayofweek", dowIndex >= 0 ? cursor.getString(dowIndex) : "");
            i.putExtra("time", timeIndex >= 0 ? cursor.getString(timeIndex) : "");
            i.putExtra("capacity", capacityIndex >= 0 ? cursor.getFloat(capacityIndex) : 0);
            i.putExtra("duration", durationIndex >= 0 ? cursor.getFloat(durationIndex) : 0);
            i.putExtra("price", priceIndex >= 0 ? cursor.getFloat(priceIndex) : 0);
            i.putExtra("type", typeIndex >= 0 ? cursor.getString(typeIndex) : "");
            i.putExtra("description", desIndex >= 0 ? cursor.getString(desIndex) : "");
            context.startActivity(i);
        });

        Button btnViewSchedule = view.findViewById(R.id.btnViewSchedule);
        btnViewSchedule.setOnClickListener(v -> {
            Intent i = new Intent(context, ClassInstancesActivity.class);
            i.putExtra("course_id", id);
            context.startActivity(i);
        });
    }
}
